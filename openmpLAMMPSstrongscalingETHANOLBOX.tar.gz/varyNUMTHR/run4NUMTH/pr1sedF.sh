#!/usr/bin/env bash
cp templateM4.txt tplback.txt
datafile=$(ls data.*)
OLV1='xFORM'
OLV2='xDATAP'
NEV1='CH3CH2OH'
NEV2=$(pwd)/$datafile
sed -e "s#${OLV1}#${NEV1}#g" -e "s#${OLV2}#${NEV2}#g" tplback.txt > outputco.txt
