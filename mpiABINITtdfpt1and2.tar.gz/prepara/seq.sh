#!/bin/bash

abinit < tdfpt_01.files > tdfpt_01.log
cp tdfpt_01.o_WFK tdfpt_02.i_WFK
cp tdfpt_01.o_WFK tdfpt_02.i_WFQ
abinit < tdfpt_02.files > tdfpt_02.log
abinit < tdfpt_03.files > tdfpt_03.log
cp tdfpt_03.o_WFK tdfpt_04.i_WFK
cp tdfpt_03.o_WFK tdfpt_04.i_WFQ
abinit < tdfpt_04.files > tdfpt_04.log
