#!/bin/bash
export OMP_NUM_THREADS=36
lmp -i in.silica -l log.out
