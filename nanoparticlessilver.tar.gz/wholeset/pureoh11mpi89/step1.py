from ase.cluster import Octahedron
from ase.calculators.emt import EMT
from ase.optimize import BFGS

atoms = Octahedron('Ag', 11)
atoms.calc = EMT()
opt = BFGS(atoms, trajectory='opt.traj')
opt.run(fmax=0.01)
