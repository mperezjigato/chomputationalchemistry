#!/usr/bin/env bash

python step1.py > outlog1.txt
python step2.py > outlog2.txt
python step3.py > outlog3.txt
