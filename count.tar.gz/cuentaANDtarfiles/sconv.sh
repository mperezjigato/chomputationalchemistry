#!/usr/bin/env bash
tmode=$1
mpifile='template2.txt'
tmpin=$(printf "template%s.txt" $tmode)
echo "$tmpin"
#
if [[ "$tmpin" == "$mpifile" ]]
then
        (>&2 echo "get your ducks in a row - BYE!")
        echo "get your ducks in a row - BYE!"
        exit 1
fi
#
if [[ ! -f "$tmpin" && ! -f "$mpifile" ]]
then
        (>&2 echo "get your ducks in a row - BYE!")
        echo "get your ducks in a row - BYE!"
        exit 1
fi
#
workh='tobedone.txt'
subf='slurm.txt'
cp $tmpin $workh
cp $mpifile $subf
#

outf=$(printf "outNPAR%s.txt" $i)

outf=$(printf "outNPAR%sCOF%s.txt" $i $j)

touch $outf

#
OLV1='xNPARAM'
OLV2='xNTRUNC'
OLV3='xNNODES'
OLV4='xNCMPI'

delimwho=( $OLV1 $OLV2 )
delimmpi=( $OLV3 $OLV4 )

printf -v linew1 "grep %s %s" ${delimwho[0]} $workh
printf -v linew2 "grep %s %s" ${delimwho[1]} $workh

lw1=`$linew1`
lw2=`$linew2`

if [[ "$lw1" != "$lw2" ]]
then
        (>&2 echo "get your ducks in a row - BYE!")
        echo "get your ducks in a row - BYE!"
        exit 1
fi

printf -v linem1 "grep %s %s" ${delimmpi[0]} $subf
printf -v linem2 "grep %s %s" ${delimmpi[1]} $subf

lm1=`$linem1`
lm2=`$linem2`

NEV1=$i
NEV2=$j
NEV3=
NEV4=

sed -e "s#${OLV1}#${NEV1}#g" template0.txt > out0.txt
sed -e "s#${OLV1}#${NEV1}#g" -e "s#${OLV2}#${NEV2}#g" template1.txt > out1.txt
sed -e "s#${OLV3}#${NEV3}#g" -e "s#${OLV4}#${NEV4}#g" template2.txt > out2.txt
