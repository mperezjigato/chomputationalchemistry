from ase.cluster import Octahedron
from ase.io import write, read
atoms = Octahedron('Ag', 11)
write('atoms.xyz', atoms)
