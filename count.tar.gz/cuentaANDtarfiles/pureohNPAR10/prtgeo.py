from ase.cluster import Octahedron
from ase.io import write, read
atoms = Octahedron('Ag', 10)
write('atoms.xyz', atoms)
