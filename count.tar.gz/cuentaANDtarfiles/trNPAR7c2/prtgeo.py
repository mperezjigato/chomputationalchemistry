from ase.cluster import Octahedron
from ase.io import write, read
atoms = Octahedron('Ag', 7, cutoff=2)
write('atoms.xyz', atoms)
