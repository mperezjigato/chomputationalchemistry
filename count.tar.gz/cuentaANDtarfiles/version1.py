from string import Template

option = 0         # pure octahedron

element = 'Ag'
ipar = 25
jpar = 2

scriptPOH = Template("$metal, $npar").substitute(metal=element, npar=ipar)
scriptTROH = Template("$metal, $npar, cutoff=$cof").substitute(metal=element, npar=ipar, cof=jpar)

if option == 0:
    scr = scriptPOH
elif option == 1:
    scr = scriptTROH
else:
    exit()

function = "Octahedron(scr)"

print(function)
