#!/usr/bin/env bash
bmtime=$(grep "Total:" output.txt | sed -e 's/Total: *//' | cut -d " " -f 1)
iterations=$(grep "Converged after" output.txt | cut -d " " -f 3)
dipole=$(grep "Dipole" output.txt | cut -d " " -f 5 | sed -e 's/)//')
fermi=$(grep "Fermi level:" output.txt | cut -d ":" -f 2 | sed -e 's/ //g')
energy=$(grep "Extrapolated: " output.txt | cut -d ":" -f 2 | sed -e 's/ //g')
echo -e "\nResult information:\n" \
    " * Time:                   $bmtime s\n" \
    " * Number of iterations:   $iterations\n" \
    " * Dipole (3rd component): $dipole\n" \
    " * Fermi level:            $fermi\n" \
    " * Extrapolated energy:    $energy\n"

