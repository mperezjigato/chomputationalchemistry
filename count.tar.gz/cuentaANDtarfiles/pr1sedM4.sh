#!/usr/bin/env bash
infile=$(ls in.*)
datafile=$(ls data.*)
cp $infile inback.txt
OLV1='CH3CH2OH'
OLV2=$(pwd)/$datafile
NEV1='xFORM'
NEV2='xDATAP'
sed -e "s#${OLV1}#${NEV1}#g" -e "s#${OLV2}#${NEV2}#g" inback.txt > outsedM4.txt

