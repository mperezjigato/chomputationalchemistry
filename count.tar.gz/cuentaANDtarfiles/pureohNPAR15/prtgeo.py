from ase.cluster import Octahedron
from ase.io import write, read
atoms = Octahedron('Ag', 15)
write('atoms.xyz', atoms)
