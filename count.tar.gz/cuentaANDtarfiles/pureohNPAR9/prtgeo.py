from ase.cluster import Octahedron
from ase.io import write, read
atoms = Octahedron('Ag', 9)
write('atoms.xyz', atoms)
